#this script is edited on 05/16/2018 

#this script is created on 03/12/2018
#this script is used to further classify the miRNA-mRNA gene pair into the positive or negative class
#the neural network includes three layers. The first layer contains 20 hidden units, the second layer contains 10 hidden units and the output layer is 2 units: ([1,0]) is the positive predicted output and ([0,1]) is the negative predicted output. 
#Author: Bi Zhao
#Python Version: 2.7.5

import numpy as np
import math
import sys
import os
import tensorflow as tf 
import keras 
from keras.layers import Dense,GaussianDropout,GlobalMaxPooling1D,Dropout,Conv1D,MaxPooling1D
from keras.models import Model
from keras import backend as K
from keras.models import Sequential



#first step Decision tree and majority voting 
#decision tree fisrt level 
def first_DT(X_train0,true_threshold1,false_threshold1,true_threshold2,false_threshold2):
	result_lst = []
	for p in range(len(X_train0)):
		x_train = X_train0[p]
		#form two binary list after compare with true or false threshold values
		true_input = []
		false_input = []
		for i in range(len(x_train)):
			if x_train[i]<=true_threshold1[i]:
				true_input.append(1)
			elif x_train[i]>true_threshold1[i]:
				true_input.append(0)
			if x_train[i]>=false_threshold1[i]:
				false_input.append(1)
			elif x_train[i]<false_threshold1[i]:
				false_input.append(0)
		#majority voting to determine the miRNA-target pair to be positive predicted or negative predicted after the first step dual threshold decision trees
		count1 = 0
		count2 = 0
		for j in range(len(x_train)):
        		if true_input[j]==1:
				count1 = count1+1
			if false_input[j]==1:
				count2 = count2+1
		if count1>count2:
			result = list(x_train-true_threshold1)
			result = [1.0,0.0,0.0,0.0,0.0,0.0] + result 
			result_lst.append(result)
		elif count2>count1:
			result = list(x_train-false_threshold1)
			result = [0.0,1.0,0.0,0.0,0.0,0.0] + result 
			result_lst.append(result)
		elif count2==count1:  #here it will go into the second level dual threshold decision tree
			second_result = second_DT(x_train,true_threshold2,false_threshold2)
			result_lst.append(second_result)
	return np.asarray(result_lst)

#second level dual thresholds decision tree 
def second_DT(x_train,true_threshold2,false_threshold2):
	#form two binary list after compare with true or false threshold values
	true_input = []
	false_input = []
	for i in range(len(x_train)):
		if x_train[i]<=true_threshold2[i]:
			true_input.append(1)
		elif x_train[i]>true_threshold2[i]:
			true_input.append(0)
		if x_train[i]>=false_threshold2[i]:
			false_input.append(1)
		elif x_train[i]<false_threshold2[i]:
			false_input.append(0)
	#majority voting followed by significant voting to determine the miRNA mRNA pair to be positive or negative
	count1 = 0
	count2 = 0
	for j in range(len(x_train)):
        	if true_input[j]==1:
			count1 = count1+1
	        if false_input[j]==1:
			count2 = count2+1
	if count1>count2:
		result = list(x_train-true_threshold2)
		result = [0.0,0.0,1.0,0.0,0.0,0.0] + result 
		return result
	elif count2>count1:
		result = list(x_train-false_threshold2)
		result = [0.0,0.0,0.0,1.0,0.0,0.0] + result 
		return result
	elif count2==count1:
		true_dist = math.sqrt(np.sum((x_train-true_threshold2)**2))/len(x_train)
		false_dist = math.sqrt(np.sum((x_train-false_threshold2)**2))/len(x_train)
		if true_dist>=false_dist:
			result = list(x_train-true_threshold2)
			result = [0.0,0.0,0.0,0.0,1.0,0.0] + result 
			return result
		elif true_dist<false_dist:
			result = list(x_train-false_threshold2)
			result = [0.0,0.0,0.0,0.0,0.0,1.0] + result 
			return result




























