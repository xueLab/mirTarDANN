#this script is created on 07/02/2018
#run this script "python miRNA_mRNA_predictor.py".
#The input file is ".txt" saved in folder input
#The output file is "_output.txt" saved in folder result
#The output file with the predicted score will show in the output file
#Author: Bi Zhao

import os
import numpy as np
from keras.models import Model
from keras import backend as k
from keras.models import load_model
import keras
import test_miRANDA_miRDB
import test_miRANDA_miRDB_PITA
import test_miRANDA_miRDB_PITA_TargetScan
import test_miRANDA_miRDB_TargetScan
import test_miRANDA_PITA
import test_miRANDA_PITA_TargetScan 
import test_miRDB_PITA 
import test_miRANDA_TargetScan 
import test_miRDB_PITA_TargetScan
import test_miRDB_TargetScan
import test_PITA_TargetScan

path = raw_input("Enter a path:")
model_dict = "model"
dataset_dict = "input"
result_dict = "result"
dataset_name = raw_input("Enter a filename:")
result_name = "_".join(dataset_name.split("_")[:-1]).strip()+"_result.txt"
dataset = os.path.join(path,dataset_dict,dataset_name)
data = np.loadtxt(dataset,dtype="str")

def miRANDA_miRDB_PITA_TargetScan(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]!="NA" and data[i][3]!="NA" and data[i][4]!="NA" and data[i][5]!="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][2]),float(data[i][3]),float(data[i][4]),float(data[i][5])])
    scores = test_miRANDA_miRDB_PITA_TargetScan.main(X_test,pair_lst,path,model_dict)
    return scores

def miRANDA_miRDB_PITA(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]!="NA" and data[i][3]!="NA" and data[i][4]!="NA" and data[i][5]=="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][2]),float(data[i][3]),float(data[i][4])])
    scores = test_miRANDA_miRDB_PITA.main(X_test,pair_lst,path,model_dict)
    return scores

def miRANDA_miRDB_TargetScan(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]!="NA" and data[i][3]!="NA" and data[i][4]=="NA" and data[i][5]!="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][2]),float(data[i][3]),float(data[i][5])])
    scores = test_miRANDA_miRDB_TargetScan.main(X_test,pair_lst,path,model_dict)
    return scores

def miRANDA_PITA_TargetScan(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]!="NA" and data[i][3]=="NA" and data[i][4]!="NA" and data[i][5]!="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][2]),float(data[i][4]),float(data[i][5])])
    scores = test_miRANDA_PITA_TargetScan.main(X_test,pair_lst,path,model_dict)
    return scores

def miRDB_PITA_TargetScan(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]=="NA" and data[i][3]!="NA" and data[i][4]!="NA" and data[i][5]!="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][3]),float(data[i][4]),float(data[i][5])])
    scores = test_miRDB_PITA_TargetScan.main(X_test,pair_lst,path,model_dict)
    return scores

def miRANDA_miRDB(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]!="NA" and data[i][3]!="NA" and data[i][4]=="NA" and data[i][5]=="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][2]),float(data[i][3])])
    scores = test_miRANDA_miRDB.main(X_test,pair_lst,path,model_dict)
    return scores

def miRANDA_PITA(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]!="NA" and data[i][3]=="NA" and data[i][4]!="NA" and data[i][5]=="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][2]),float(data[i][4])])
    scores = test_miRANDA_PITA.main(X_test,pair_lst,path,model_dict)
    return scores

def miRANDA_TargetScan(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]!="NA" and data[i][3]=="NA" and data[i][4]=="NA" and data[i][5]!="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][2]),float(data[i][5])])
    scores = test_miRANDA_TargetScan.main(X_test,pair_lst,path,model_dict)
    return scores

def miRDB_PITA(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]=="NA" and data[i][3]!="NA" and data[i][4]!="NA" and data[i][5]=="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][3]),float(data[i][4])])
    scores = test_miRDB_PITA.main(X_test,pair_lst,path,model_dict)
    return scores

def miRDB_TargetScan(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]=="NA" and data[i][3]!="NA" and data[i][4]=="NA" and data[i][5]!="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][3]),float(data[i][5])])
    scores = test_miRDB_TargetScan.main(X_test,pair_lst,path,model_dict)
    return scores

def PITA_TargetScan(data):
    pair_lst = []
    X_test = []
    for i in range(len(data)):
        if data[i][2]=="NA" and data[i][3]=="NA" and data[i][4]!="NA" and data[i][5]!="NA":
            pair_lst.append(data[i][0]+"\t"+data[i][1])
            X_test.append([float(data[i][4]),float(data[i][5])])
    scores = test_PITA_TargetScan.main(X_test,pair_lst,path,model_dict)
    return scores

def main():
    miRANDA_miRDB_PITA_TargetScan_scores = miRANDA_miRDB_PITA_TargetScan(data)
    miRANDA_miRDB_PITA_scores = miRANDA_miRDB_PITA(data)
    miRANDA_miRDB_TargetScan_scores = miRANDA_miRDB_TargetScan(data)
    miRANDA_PITA_TargetScan_scores = miRANDA_PITA_TargetScan(data)
    miRDB_PITA_TargetScan_scores = miRDB_PITA_TargetScan(data)
    miRANDA_miRDB_scores = miRANDA_miRDB(data)
    miRANDA_PITA_scores = miRANDA_PITA(data)
    miRANDA_TargetScan_scores = miRANDA_TargetScan(data)
    miRDB_PITA_scores = miRDB_PITA(data)
    miRDB_TargetScan_scores = miRDB_TargetScan(data)
    PITA_TargetScan_scores = PITA_TargetScan(data)
    scores = miRANDA_miRDB_PITA_TargetScan_scores + miRANDA_miRDB_PITA_scores + miRANDA_miRDB_TargetScan_scores + miRANDA_PITA_TargetScan_scores + miRDB_PITA_TargetScan_scores + miRANDA_miRDB_scores + miRANDA_PITA_scores + miRANDA_TargetScan_scores + miRDB_PITA_scores + miRDB_TargetScan_scores + PITA_TargetScan_scores
    results = os.path.join(path,result_dict,result_name)
    x = open(results,"wt")
    for j in scores:
	    x.write(j+"\n")


main()
