#this script is created on 06/14/2018 to find the miRNA-mRNA pairs that can be identified by new predictor
#Author: Bi Zhao

import os
import numpy as np
from keras.models import Model
from keras import backend as K
import keras
from DT_helper_function import *
from keras.models import load_model

true_threshold1 = np.array([0.3754,-0.6236])
true_threshold2 = np.array([0.4736,-0.6036])#-0.6036
false_threshold1 = np.array([0.7156,-0.4474])
false_threshold2 = np.array([0.5334,-0.5355])#-0.5355

model_name = "miRANDA_miRDB_model.h5"

def normalized(x):
    min_array = np.array([-1.3569, -99.9823])
    max_array = np.array([-0.1, -50.0])
    normal = max_array-min_array
    #normal = [max(a)-min(a) for a in x.T]
    return (x-min_array)*2/normal-1


def evaluatef(scores,pair_lst,Y_test):
	TP = []
	TN = []
	FP = []
	FN = []
	for i in range(len(scores)):
		if Y_test[i][0] == 1.0 and scores[i][0] >= scores[i][1]:
			TP.append(pair_lst[i]+"\t"+str(scores[i][0]-scores[i][1]))
		elif Y_test[i][0] == 1.0 and scores[i][0] <= scores[i][1]:
			FN.append(pair_lst[i]+"\t"+str(scores[i][0])+"\t"+str(scores[i][1]))
		elif Y_test[i][0] == 0.0 and scores[i][0] <= scores[i][1]:
			TN.append(pair_lst[i]+"\t"+str(scores[i][0])+"\t"+str(scores[i][1]))
		elif Y_test[i][0] == 0.0 and scores[i][0] >= scores[i][1]:
			FP.append(pair_lst[i]+"\t"+str(scores[i][0])+"\t"+str(scores[i][1]))
	return TP, FN, TN, FP


def predictf(scores,pair_lst):
	pairs = []
	for i in range(len(scores)):
		pairs.append(pair_lst[i]+"\t"+str(scores[i][0]-scores[i][1]))
	return pairs


def main(X_test,pair_lst,path,model_dict):
	import_model = os.path.join(path,model_dict,model_name)
	model = load_model(import_model)
	model.summary()
	X_test = normalized(np.array(X_test))
	X_test = first_DT(X_test,true_threshold1,false_threshold1,true_threshold2,false_threshold2)
	scores = model.predict(X_test,verbose=1)
	pairs = predictf(scores,pair_lst)
	return pairs









